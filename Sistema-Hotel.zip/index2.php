<?php
header("location: /web/");
?>