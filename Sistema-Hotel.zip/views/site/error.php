<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = $name;
?>
<div class="site-error">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="alert alert-danger">
        <?= nl2br(Html::encode($message)) ?>
    </div>

    <p>
        Este error ocurrió mientras el servidor Web procesaba tu solicitud.
    </p>
    <p>
        Por favor contacta con tu distribuidor para resolver este problema.
    </p>

</div>
